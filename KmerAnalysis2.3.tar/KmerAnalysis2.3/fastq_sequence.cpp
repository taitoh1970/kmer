/*
 * fastq_sequence.cpp
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#include <iostream>
#include <zlib.h>
#include <climits>
#include "fastq_sequence.h"
#include "bitcalc.h"

FastqSequence::FastqSequence() {
}

FastqSequence::~FastqSequence() {
}

/**
 * Input read data.
 */
std::unordered_map<std::string, unsigned long> FastqSequence::readFastq(
		const std::string &fastqFile, const unsigned int kmer,
		const unsigned long &max_buff,
		std::unordered_map<std::string, unsigned long> &hcount,
		const unsigned char *dna2bit, const unsigned char *chunk,
		unsigned long &countmer) const {
	// File mode
	gzFile file = gzopen(fastqFile.c_str(), "rb");
	if (!file) {
		std::cerr << "[Error] " << "Could not open " << fastqFile << std::endl;
		std::exit(1);
	}

	std::unordered_map<std::string, unsigned long> hcount2;
	char buff[max_buff];
	std::string mer;
	std::string aLine[4];
	unsigned int nLine = 0;
	unsigned long nMers = 0;

	while (gzgets(file, buff, max_buff) != Z_NULL) {
		aLine[nLine++] = std::string(buff);
		if (nLine == 4) {
			nLine = 0;
			if (++nMers % 1000000 == 0) {
				std::cerr << fastqFile << ": parsing " << nMers << " reads." << std::endl;
			}

			if (aLine[0][0] != '@' || aLine[2][0] != '+') {
				aLine[0].erase(--aLine[0].end());
				std::cerr << "ERROR: Couldn't get sequence (" << aLine[0] << ")." << std::endl;
				exit(1);
			}

			if (aLine[1].length() > kmer) {
				// Delete line break (\n)
				aLine[1].erase(--aLine[1].end());

				unsigned int dnabit = dna2bit[(unsigned char)aLine[1][0]];
				for (int i = 1; i < CHUNKLENGTH - 1; i++) {
					dnabit = (dnabit << 2) + dna2bit[(unsigned char)aLine[1][i]];
				}
				for (unsigned long i = 0; i <= aLine[1].length() - kmer; i++) {
					countmer++;
					dnabit = (dnabit << 2) + dna2bit[(unsigned char)aLine[1][CHUNKLENGTH - 1 + i]];
					if (dnabit == UINT_MAX || chunk[dnabit] == 1) {
						mer.assign(aLine[1], i, kmer);
						//if (hcount.count(mer) > 0) {
						if (hcount.find(mer) != hcount.end()) {
							hcount2[mer]++;
						}
					}
				}
			}
		}
	}
	gzclose(file);
	return hcount2;
}
