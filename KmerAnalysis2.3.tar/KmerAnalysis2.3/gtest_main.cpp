//============================================================================
// Name        : KmerAnalysis gtest
// Author      : NARO
// Version     : 201902
// Copyright   : (c) 2018 National Agriculture and Food Research Organization (NARO)
// Description : Kmer analysis gtest
//============================================================================

#include <stdexcept>
#include "gtest.h"

int main(int argc, char* argv[]) {
	/**
	 * Input information.
	 */
	InputInfo inputInfo;

	std::string version = "\nProgram: KmerAnalysis gtest\nVersion: 201902\n";

	std::string help = "Usage  : gtest posFreq.txt(case) posFreq.txt(control) #totalCaseMers #totalControlMers out_prefix\n";

	if (argc != 6) {
		std::cout << version << std::endl;
		std::cout << help << std::endl;
		return 0;
	} else {
		try {
			inputInfo.caseFile = argv[1];
			inputInfo.controlFile = argv[2];
			inputInfo.caseMers = std::stol(argv[3]);
			inputInfo.controlMers = std::stol(argv[4]);
			inputInfo.prefix = argv[5];
		} catch (const std::invalid_argument &e) {
		  	std::cerr << "[Error] " << argv[0] << ": invalid argument." << std::endl;
			return EXIT_FAILURE;
		} catch (const std::out_of_range &e) {
		  	std::cerr << "[Error] " << argv[0] << ": out of range." << std::endl;
			return EXIT_FAILURE;
		} catch (const std::bad_alloc &e) {
			std::cerr << "[Error] " << argv[0] << ": out of memory." << std::endl;
			return EXIT_FAILURE;
		} catch (const std::exception &e) {
			const char *s = e.what();
			if (*s) {
			  std::cerr << "[Error] " << argv[0] << ": " << s << std::endl;
			}
			return EXIT_FAILURE;
		}
	}

	/**
	 * Analysis of kmer data (gtest).
	 */
	try {
		Gtest *gtest = new Gtest(inputInfo);
		gtest->execution();
		delete gtest;
		return EXIT_SUCCESS;
	} catch (const std::bad_alloc &e) {
		std::cerr << "[Error] " << argv[0] << ": out of memory." << std::endl;
		return EXIT_FAILURE;
	} catch (const std::exception &e) {
		const char *s = e.what();
		if (*s) {
		  std::cerr << "[Error] " << argv[0] << ": " << s << std::endl;
		}
		return EXIT_FAILURE;
	}
}
