/*
 * bitcalc.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef BITCALC_H_
#define BITCALC_H_

/**
 * Bit calculation parameter.
 */

static const int CHUNKLENGTH = 16;

#endif /* BITCALC_H_ */
