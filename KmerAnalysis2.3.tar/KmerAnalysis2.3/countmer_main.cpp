//============================================================================
// Name        : KmerAnalysis countmer
// Author      : NARO
// Version     : 201902
// Copyright   : (c) 2018 National Agriculture and Food Research Organization (NARO)
// Description : Kmer count in the read sequences
//============================================================================

#include "countmer.h"
#include "bitcalc.h"

int main(int argc, char* argv[]) {
	/**
	 * Execution options.
	 */
	Options options;

	/**
	 * Max read length (default = 512)
	 */
	options.max_read_length = 512;

	std::string version = "\nProgram: KmerAnalysis countmer\nVersion: 201902\n";

	std::string help = "Usage  : countmer vector_seq(fasta) read1(fastq.gz) read2(fastq.gz) kmer(e.g.20) out_prefix [max_read_length(+2) (512)]\n";

	if (argc < 6 || argc > 7) {
		std::cout << version << std::endl;
		std::cout << help << std::endl;
		return 0;
	} else {
		try {
			options.vectorFile = argv[1];
			options.fastq1File = argv[2];
			options.fastq2File = argv[3];
			int kmer = std::stoi(argv[4]);
			if (kmer >= CHUNKLENGTH) {
			  options.kmer = kmer;
			} else {
			  std::cerr << "[Error] kmer (" << kmer << ") >= " << CHUNKLENGTH << "." << std::endl;
			  return EXIT_FAILURE;
			}
			options.prefix = argv[5];
			if (argc == 7) {
			  long max_read_length = std::stol(argv[6]);
			  if (max_read_length > 2) {
			    options.max_read_length = max_read_length;
			  } else {
			    std::cerr << "[Error] max_read_length(+2) (" << max_read_length << ") is too small." << std::endl;
			    return EXIT_FAILURE;
			  }
			}
		} catch (const std::invalid_argument &e) {
		  	std::cerr << "[Error] " << argv[0] << ": invalid argument." << std::endl;
		  	return EXIT_FAILURE;
		} catch (const std::out_of_range &e) {
			std::cerr << "[Error] " << argv[0] << ": out of range." << std::endl;
			return EXIT_FAILURE;
		} catch (const std::bad_alloc &e) {
			std::cerr << "[Error] " << argv[0] << ": out of memory." << std::endl;
			return EXIT_FAILURE;
		} catch (const std::exception &e) {
			const char *s = e.what();
			if (*s) {
				std::cerr << "[Error] " << argv[0] << ": " << s << std::endl;
			}
			return EXIT_FAILURE;
		}
	}

	/**
	 * Analysis of kmer data (countmer).
	 */
	try {
		CountMer *countMer = new CountMer(options);
		countMer->execution();
		delete countMer;
		return EXIT_SUCCESS;
	} catch (const std::bad_alloc& e) {
		std::cerr << "[Error] " << argv[0] << ": out of memory." << std::endl;
		return EXIT_FAILURE;
	} catch (const std::exception &e) {
		const char *s = e.what();
		if (*s) {
			std::cerr << "[Error] " << argv[0] << ": " << s << std::endl;
		}
		return EXIT_FAILURE;
	}
}
