/*
 * vector_sequence.h
 *
 *  Created on: 2018/02/23, modified on:2019/02/22
 *      Author: NARO
 */

#ifndef VECTOR_SEQUENCE_H_
#define VECTOR_SEQUENCE_H_

#include <string>
#include <unordered_map>

/**
 * Input vector sequences.
 */
class VectorSequence {

public:
	VectorSequence();
	virtual ~VectorSequence();

	/**
	 * Read the fasta file.
	 */
	void readFasta(const std::string &vectorFile, const unsigned int kmer,
			std::unordered_map<std::string, unsigned long> &hcount,
			std::unordered_map<unsigned long, std::pair<std::string, std::string> > &hpos,
			const unsigned char *dna2bit, unsigned char *chunk) const;

private:
	/**
	 * Set kmer in hash table.
	 */
	void kmerSet(std::string &sequence, const unsigned int kmer,
			std::unordered_map<std::string, unsigned long> &hcount,
			std::unordered_map<unsigned long, std::pair<std::string, std::string> > &hpos) const;

	/**
	 * Set chunk in hash table.
	 */
	void chunkSet(std::unordered_map<std::string, unsigned long> &hcount,
			const unsigned char *dna2bit, unsigned char *chunk) const;
};

#endif /* VECTOR_SEQUENCE_H_ */
