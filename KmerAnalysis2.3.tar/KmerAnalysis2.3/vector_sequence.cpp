/*
 * vector_sequence.cpp
 *
 *  Created on: 2018/02/23, modified on: 2018/06/28, modified on: 2019/02/22
 *      Author: NARO
 */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <climits>
#include "vector_sequence.h"
#include "bitcalc.h"

VectorSequence::VectorSequence() {
}

VectorSequence::~VectorSequence() {
}

/**
 * Read the fasta file.
 */
void VectorSequence::readFasta(const std::string &vectorFile, const unsigned int kmer,
		std::unordered_map<std::string, unsigned long> &hcount,
		std::unordered_map<unsigned long, std::pair<std::string, std::string> > &hpos,
		const unsigned char *dna2bit, unsigned char *chunk) const {
	std::ifstream ifs(vectorFile.c_str());
	if (!ifs) {
		std::cerr << "[Error] " << "Could not open " << vectorFile << std::endl;
		std::exit(1);
	}

	std::string str;
	std::string sequence = "";
	while (getline(ifs, str)) {
		if (str[0] == '>') {
			this->kmerSet(sequence, kmer, hcount, hpos);
			sequence = "";
		} else {
			// Delete line breaks
			if (str[str.size() - 1] == '\n') {
				str.erase(--str.end());
			}
			if (str[str.size() - 1] == '\r') {
				str.erase(--str.end());
			}
			sequence += str;
		}
	}
	this->kmerSet(sequence, kmer, hcount, hpos);
	this->chunkSet(hcount, dna2bit, chunk);
}

//========== Private function ==========//
/**
 * Set kmer in hash table.
 */
void VectorSequence::kmerSet(std::string &sequence, const unsigned int kmer,
		std::unordered_map<std::string, unsigned long> &hcount,
		std::unordered_map<unsigned long, std::pair<std::string, std::string> > &hpos) const {
	unsigned long vectorLength = sequence.length();
	if (vectorLength > 0) {
		sequence += sequence.substr(0, kmer - 1);
		// Convert to upper case
		transform(sequence.begin(), sequence.end(), sequence.begin(), ::toupper);
		for (unsigned long i = 0; i < vectorLength; i++) {
			std::string mer = sequence.substr(i, kmer);
			std::string revMer(mer);
			// Complementary sequence of kmer
			reverse(revMer.begin(), revMer.end());
			for (unsigned int j = 0; j < kmer; j++) {
				switch (revMer[j]) {
				case 'A':
					revMer[j] = 'T';
					break;
				case 'T':
					revMer[j] = 'A';
					break;
				case 'G':
					revMer[j] = 'C';
					break;
				case 'C':
					revMer[j] = 'G';
					break;
				default:
					break;
				}
			}
			hcount[mer] = 0;
			hcount[revMer] = 0;
			hpos[i + 1] = make_pair(mer, revMer);
		}
	}
}
/**
 * Set chunk in hash table.
 */
void VectorSequence::chunkSet(std::unordered_map<std::string, unsigned long> &hcount,
		const unsigned char *dna2bit, unsigned char *chunk) const {
	for (std::unordered_map<std::string, unsigned long>::iterator itr =
			hcount.begin(); itr != hcount.end(); ++itr) {
		unsigned int dnabit = dna2bit[(unsigned char)itr->first[0]];
		for (int i = 1; i < CHUNKLENGTH; i++) {
			dnabit = (dnabit << 2) + dna2bit[(unsigned char)itr->first[i]];
		}
		if (dnabit != UINT_MAX) {
			chunk[dnabit] = 1;
		}
	}
}
