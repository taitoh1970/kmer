/*
 * countmer.cpp
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#include <fstream>
#include <map>
#include <climits>
#include "countmer.h"
#include "bitcalc.h"

#ifdef _OPENMP
#include <omp.h>
#endif

/**
 * Count mer.
 */
CountMer::CountMer(const Options &opts) {
	this->options = opts;
	this->vectorSequence = new VectorSequence();
	this->fastqSequence = new FastqSequence();
	this->chunk = new unsigned char[UINT_MAX];
	for (unsigned long i = 0; i < UINT_MAX; i++) {
	  this->chunk[i] = 0;
	}
	this->dna2bit = new unsigned char[128];
	for (int i = 0; i < 128; i++) {
	  this->dna2bit[i] = 0;
	}
	this->dna2bit[84] = 0;	// T or others
	this->dna2bit[67] = 1;	// C
	this->dna2bit[65] = 2;	// A
	this->dna2bit[71] = 3;	// G
}

CountMer::~CountMer() {
	delete[] this->dna2bit;
	delete[] this->chunk;
	delete this->fastqSequence;
	delete this->vectorSequence;
}

/**
 * Execute kmer analysis.
 */
void CountMer::execution() {
	unsigned int kmer = this->options.kmer;
	unsigned long max_read_length = this->options.max_read_length;

	// Hash tables
	std::unordered_map<std::string, unsigned long> hHASH_COUNT;
	std::unordered_map<unsigned long, std::pair<std::string, std::string> > hVECTOR_POS_MER;

	/**
	 * Read the fasta file
	 */
	this->vectorSequence->readFasta(this->options.vectorFile, kmer, hHASH_COUNT,
			hVECTOR_POS_MER, this->dna2bit, this->chunk);

	//========== Read fastq files (fastq.gz) ==========//
	unsigned long countmer = 0;

#ifdef _OPENMP
#pragma omp parallel sections
	{
#pragma omp section
		{
#endif
	unsigned long countmer1 = 0;
	/**
	 * Read the fastq.gz file (R1)
	 */
	std::unordered_map<std::string, unsigned long> hHASH_COUNT2 =
			this->fastqSequence->readFastq(this->options.fastq1File, kmer,
					max_read_length, hHASH_COUNT, this->dna2bit, this->chunk, countmer1);
#ifdef _OPENMP
#pragma omp critical(count)
#endif
	countmer += countmer1;
#ifdef _OPENMP
#pragma omp critical(hash)
#endif
	for (std::unordered_map<std::string, unsigned long>::iterator itr =
			hHASH_COUNT.begin(); itr != hHASH_COUNT.end(); ++itr) {
		hHASH_COUNT[itr->first] += hHASH_COUNT2[itr->first];
	}
#ifdef _OPENMP
}
#pragma omp section
{
#endif
	unsigned long countmer2 = 0;
	/**
	 * Read the fastq.gz file (R2)
	 */
	std::unordered_map<std::string, unsigned long> hHASH_COUNT2 =
			this->fastqSequence->readFastq(this->options.fastq2File, kmer,
					max_read_length, hHASH_COUNT, this->dna2bit, this->chunk, countmer2);
#ifdef _OPENMP
#pragma omp critical(count)
#endif
	countmer += countmer2;
#ifdef _OPENMP
#pragma omp critical(hash)
#endif
	for (std::unordered_map<std::string, unsigned long>::iterator itr =
			hHASH_COUNT.begin(); itr != hHASH_COUNT.end(); ++itr) {
		hHASH_COUNT[itr->first] += hHASH_COUNT2[itr->first];
	}
#ifdef _OPENMP
}
}
#endif

	//========== Output ==========//
#ifdef _OPENMP
#pragma omp parallel sections
	{
#pragma omp section
		{
#endif
	/**
	 * Write the posFreq.txt file.
	 */
	this->posFreq(hHASH_COUNT, hVECTOR_POS_MER);
#ifdef _OPENMP
}
#pragma omp section
{
#endif
	/**
	 * Write the merFreq.txt file.
	 */
	this->merFreq(hHASH_COUNT);
#ifdef _OPENMP
}
}
#endif
	std::cout << countmer << std::endl;
}

//==============================================//
//========== Private function ==========//
//==============================================//
/**
 * Write the posFreq.txt file.
 */
void CountMer::posFreq(std::unordered_map<std::string, unsigned long> &hcount,
		std::unordered_map<unsigned long, std::pair<std::string, std::string> > &hpos) const {
	std::string outfile = this->options.prefix + ".posFreq.txt";
	std::ofstream ofs(outfile.c_str());
	if (!ofs) {
		std::cerr << "[Error] " << "Could not open " << outfile << std::endl;
		std::exit(1);
	}

	std::map<unsigned long, std::pair<std::string, std::string> > sortedPos(
			hpos.begin(), hpos.end());

	for (std::map<unsigned long, std::pair<std::string, std::string> >::iterator itr =
			sortedPos.begin(); itr != sortedPos.end(); ++itr) {
		ofs << itr->first << '\t'
				<< hcount[itr->second.first] + hcount[itr->second.second] << std::endl;
	}
	ofs.close();
}

/**
 * Write the merFreq.txt file.
 */
void CountMer::merFreq(
		const std::unordered_map<std::string, unsigned long> &hcount) const {
	std::string outfile = this->options.prefix + ".merFreq.txt";
	std::ofstream ofs(outfile.c_str());
	if (!ofs) {
		std::cerr << "[Error] " << "Could not open " << outfile << std::endl;
		std::exit(1);
	}

	std::map<std::string, unsigned long> sortedCount(hcount.begin(),
			hcount.end());

	for (std::map<std::string, unsigned long>::iterator itr =
			sortedCount.begin(); itr != sortedCount.end(); ++itr) {
		ofs << itr->first << '\t' << itr->second << std::endl;
	}
	ofs.close();
}
