/*
 * fastq_sequence.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef FASTQ_SEQUENCE_H_
#define FASTQ_SEQUENCE_H_

#include <string>
#include <unordered_map>

/**
 * Input read data.
 */
class FastqSequence {
public:
	FastqSequence();
	virtual ~FastqSequence();

	/**
	 * Read the fastq.gz file.
	 */
	std::unordered_map<std::string, unsigned long> readFastq(
			const std::string &vectorFile, const unsigned int kmer,
			const unsigned long &max_buff,
			std::unordered_map<std::string, unsigned long> &hcount,
			const unsigned char *dna2bit, const unsigned char *chunk,
			unsigned long &countmer) const;
};

#endif /* FASTQ_SEQUENCE_H_ */
