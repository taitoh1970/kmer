/*
 * gtest.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef GTEST_H_
#define GTEST_H_

#include "inputinfo.h"
#include "posfreq_list.h"

/**
 * Run the Gtest.
 */
class Gtest {
public:
	Gtest(const InputInfo &info);
	virtual ~Gtest();

	/**
	 * Execute kmer analysis (gtest).
	 */
	void execution() const;

private:
	/**
	 * Input information.
	 */
	InputInfo inputInfo;

	/**
	 * Read the posFreq file.
	 */
	PosFreqList *posFreqList;
};

#endif /* GTEST_H_ */
