/*
 * posfreq_list.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef POSFREQ_LIST_H_
#define POSFREQ_LIST_H_

#include <string>
#include <vector>

/**
 * Input posFreq.txt
 */
class PosFreqList {
public:
	PosFreqList();
	virtual ~PosFreqList();

	/**
	 * Read the posFreq.txt file.
	 */
	std::vector<long> readPosFreq(const std::string &posFreqFile) const;
};

#endif /* POSFREQ_LIST_H_ */
