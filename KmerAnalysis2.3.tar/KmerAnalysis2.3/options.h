/*
 * options.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef OPTIONS_H_
#define OPTIONS_H_

#include <iostream>
#include <string>

/**
 * Execution options.
 */
class Options {
public:
	std::string vectorFile;
	std::string fastq1File;
	std::string fastq2File;
	unsigned int kmer;
	std::string prefix;
	unsigned long max_read_length;

	void output() {
		std::cout << "\n---------- Kmer analysis parameters (countmer) ----------" << std::endl;
		std::cout << "Vector file = " << this->vectorFile << std::endl;
		std::cout << "Read 1 file = " << this->fastq1File << std::endl;
		std::cout << "Read 2 file = " << this->fastq2File << std::endl;
		std::cout << "Kmer        = " << this->kmer << std::endl;
		std::cout << "Prefix      = " << this->prefix << std::endl;
		std::cout << "Max read length = " << this->max_read_length << std::endl;
	}
};

#endif /* OPTIONS_H_ */
