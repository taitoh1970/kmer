/*
 * countmer.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef COUNTMER_H_
#define COUNTMER_H_

#include "options.h"
#include "vector_sequence.h"
#include "fastq_sequence.h"

/**
 * Kmer count in the read sequences.
 */
class CountMer {
public:
	CountMer(const Options &opts);
	virtual ~CountMer();

	/**
	 * Execute kmer count.
	 */
	void execution();

private:
	unsigned char *chunk;
	unsigned char *dna2bit;

	/**
	 * Execution options.
	 */
	Options options;

	/**
	 * Input vector sequences.
	 */
	VectorSequence *vectorSequence;

	/**
	 * Input read data.
	 */
	FastqSequence *fastqSequence;

	/**
	 * Write the posFreq.txt file.
	 */
	void posFreq(std::unordered_map<std::string, unsigned long> &hcount,
			std::unordered_map<unsigned long, std::pair<std::string, std::string> > &hpos) const;

	/**
	 * Write the merFreq.txt file.
	 */
	void merFreq(
			const std::unordered_map<std::string, unsigned long> &hcount) const;
};

#endif /* COUNTMER_H_ */
