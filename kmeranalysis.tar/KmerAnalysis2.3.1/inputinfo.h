/*
 * inputinfo.h
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#ifndef INPUTINFO_H_
#define INPUTINFO_H_

#include <iostream>
#include <string>

/**
 * Input information.
 */
class InputInfo {
public:
	std::string caseFile;
	std::string controlFile;
	unsigned long caseMers;
	unsigned long controlMers;
	std::string prefix;

	void output() {
		std::cout << "\n---------- Kmer analysis parameters (gtest) ----------" << std::endl;
		std::cout << "Case posFreq file     = " << this->caseFile << std::endl;
		std::cout << "Control posFreq file  = " << this->controlFile << std::endl;
		std::cout << "# total case mers     = " << this->caseMers << std::endl;
		std::cout << "# total control mers  = " << this->controlMers << std::endl;
		std::cout << "Prefix                = " << this->prefix << std::endl;
	}
};

#endif /* INPUTINFO_H_ */
