/*
 * posfreq_list.cpp
 *
 *  Created on: 2018/02/23
 *      Author: NARO
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include "posfreq_list.h"

PosFreqList::PosFreqList() {
}

PosFreqList::~PosFreqList() {
}

/**
 * Read the posFreq.txt file.
 */
std::vector<long> PosFreqList::readPosFreq(const std::string &posFreqFile) const {
	std::ifstream ifs(posFreqFile.c_str());
	if (!ifs) {
		std::cerr << "[Error] " << "Could not open " << posFreqFile	<< std::endl;
		std::exit(1);
	}

	std::vector<long> posFreq;
	std::string line;

	while (getline(ifs, line)) {
		std::istringstream iss(line);
		std::string str;
		std::vector<std::string> position;
		while (getline(iss, str, '\t')) {
			position.push_back(str);
		}
		posFreq.push_back(std::stol(position[1].c_str()));
	}
	return posFreq;
}
