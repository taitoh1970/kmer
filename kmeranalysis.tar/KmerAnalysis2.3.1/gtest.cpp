/*
 * gtest.cpp
 *
 *  Created on: 2018/02/23, modified on: 2018/06/28, modified on: 2018/11/30,
 *                          modified on: 2019/02/22
 *      Author: NARO
 */

#include <fstream>
#include <cmath>
#include "gtest.h"

/**
 * Run the Gtest.
 */
Gtest::Gtest(const InputInfo &info) {
	this->inputInfo = info;
	this->posFreqList = new PosFreqList();
}

Gtest::~Gtest() {
	delete this->posFreqList;
}

/**
 * Execute kmer analysis.
 */
void Gtest::execution() const {
	//========== Read posFreq.txt files ==========//
	std::vector<long> casePosFreq = this->posFreqList->readPosFreq(
			this->inputInfo.caseFile);
	std::vector<long> controlPosFreq = this->posFreqList->readPosFreq(
			this->inputInfo.controlFile);

	std::string outfile = this->inputInfo.prefix + ".result";
	std::ofstream ofs(outfile.c_str());
	if (!ofs) {
		std::cerr << "[Error] " << "Could not open " << outfile << std::endl;
		std::exit(1);
	}

	double case_total = this->inputInfo.caseMers;
	double case_total_log = log(case_total) * case_total;
	double control_total = this->inputInfo.controlMers;
	double control_total_log = log(control_total) * control_total;

	double total = case_total + control_total;
	double q3 = log(total) * total;
	double qcomm = (total / case_total + total / control_total - 1.0)
			/ (6.0 * total);

	for (unsigned long i = 0; i < casePosFreq.size(); i++) {
		double case_match = casePosFreq[i];
		double case_match_log = log(case_match) * case_match;
		double control_match = controlPosFreq[i];
		double control_match_log = log(control_match) * control_match;

		double case_notmatch = case_total - case_match;
		double case_notmatch_log = log(case_notmatch) * case_notmatch;
		double control_notmatch = control_total - control_match;
		double control_notmatch_log = log(control_notmatch) * control_notmatch;

		double match = case_match + control_match;
		double match_log = log(match) * match;
		double notmatch = case_notmatch + control_notmatch;
		double notmatch_log = log(notmatch) * notmatch;

		double q1;
		if (case_match == 0 && control_match == 0) {
			q1 = case_notmatch_log + control_notmatch_log;
		} else if (control_match == 0) {
			q1 = case_match_log + case_notmatch_log + control_notmatch_log;
		} else if (case_match == 0) {
			q1 = case_notmatch_log + control_match_log + control_notmatch_log;
		} else {
			q1 = case_match_log + case_notmatch_log + control_match_log
					+ control_notmatch_log;
		}

		double q2 =	match == 0 ?
		  case_total_log + control_total_log + notmatch_log :
		  case_total_log + control_total_log + match_log + notmatch_log;

		// Compute G
		double g = 2.0 * (q1 - q2 + q3);

		// Williams's correction for 2 x 2 table is ...
		double q = match == 0 ?
		  1.0 + (total / notmatch - 1.0) * qcomm :
		  1.0 + (total / match + total / notmatch - 1.0) * qcomm;
		double g_adj = g / q;

		//========== Output ==========//
		if (case_match*control_total >= control_match*case_total) {
			if (g_adj >= 6.634) {
				ofs << i + 1 << '\t' << casePosFreq[i] << '\t' << controlPosFreq[i] << '\t' << g_adj << "\t*" << std::endl;
			} else {
				ofs << i + 1 << '\t' << casePosFreq[i] << '\t' << controlPosFreq[i] << '\t' << g_adj << '\t' << std::endl;
			}
		} else {
			ofs << i + 1 << '\t' << casePosFreq[i] << '\t' << controlPosFreq[i] << '\t' << -g_adj << '\t' << std::endl;
		}
	}
	ofs.close();
}
